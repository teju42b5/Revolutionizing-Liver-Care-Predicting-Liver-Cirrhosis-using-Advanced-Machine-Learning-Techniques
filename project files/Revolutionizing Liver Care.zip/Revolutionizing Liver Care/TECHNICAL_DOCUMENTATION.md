# Technical Documentation

## Architecture Overview

The Liver Cirrhosis Prediction System is built using a modern React architecture with TypeScript for type safety and Tailwind CSS for styling. The application follows a component-based architecture with clear separation of concerns.

## Core Components

### App.tsx
Main application component that manages:
- Navigation state between dashboard, prediction form, and results
- Patient data state management
- Prediction result state management
- Header navigation and routing logic

### Dashboard.tsx
Comprehensive dashboard featuring:
- System statistics and metrics
- Recent predictions table
- Model performance indicators
- Risk distribution charts
- Quick action buttons

### PatientForm.tsx
Advanced form component with:
- Multi-section data input (demographics, lab results, clinical findings, medical history)
- Real-time validation
- Normal range indicators for lab values
- Responsive grid layout
- Accessibility features

### PredictionResults.tsx
Results display component showing:
- Risk score visualization
- Confidence indicators
- Risk factor analysis
- Clinical recommendations
- Disease staging information
- Patient summary

## Machine Learning Implementation

### mlModel.ts
The prediction engine implements a sophisticated scoring algorithm:

#### Scoring Methodology
1. **Age Factor**: Progressive risk increase with age
2. **Laboratory Values**: Weighted scoring based on deviation from normal ranges
3. **Clinical Findings**: Severity-based scoring for ascites, edema, hepatomegaly
4. **Medical History**: High-impact scoring for alcoholism, hepatitis infections

#### Risk Calculation
```typescript
// Example scoring logic
const ageScore = Math.min((data.age - 20) * 0.8, 20);
const bilirubinScore = data.bilirubin > 1.2 ? (data.bilirubin - 1.2) * 15 : 0;
const albuminScore = data.albumin < 3.5 ? (3.5 - data.albumin) * 20 : 0;
```

#### Risk Stratification
- **Low Risk (0-24%)**: Minimal intervention required
- **Moderate Risk (25-49%)**: Increased monitoring
- **High Risk (50-74%)**: Active medical management
- **Very High Risk (75-100%)**: Urgent intervention

#### Disease Staging
Automated staging based on clinical criteria:
- **Stage 1**: Mild fibrosis
- **Stage 2**: Moderate fibrosis  
- **Stage 3**: Severe fibrosis
- **Stage 4**: Cirrhosis

## Type System

### medical.ts
Comprehensive TypeScript interfaces:

```typescript
interface PatientData {
  // Demographics
  age: number;
  gender: 'male' | 'female';
  
  // Laboratory Tests
  bilirubin: number;
  albumin: number;
  alkalinePhosphatase: number;
  sgot: number;
  platelets: number;
  prothrombinTime: number;
  
  // Clinical Parameters
  ascites: 'none' | 'slight' | 'moderate' | 'severe';
  hepatomegaly: boolean;
  spiders: boolean;
  edema: 'none' | 'slight' | 'moderate' | 'severe';
  
  // Medical History
  alcoholism: boolean;
  hepatitisB: boolean;
  hepatitisC: boolean;
  fattyLiver: boolean;
}
```

## State Management

### Local State Pattern
The application uses React's built-in state management:
- `useState` for component-level state
- Props drilling for data flow
- Event handlers for state updates

### Data Flow
1. User inputs data in PatientForm
2. Form validation occurs in real-time
3. Submission triggers ML prediction
4. Results are calculated and displayed
5. Navigation state updates to show results

## Styling Architecture

### Tailwind CSS Implementation
- Utility-first approach for rapid development
- Custom color palette for medical applications
- Responsive design with mobile-first approach
- Component-specific styling patterns

### Design System
```css
/* Primary Colors */
blue-600: #2563EB (Primary actions)
blue-100: #DBEAFE (Light backgrounds)

/* Status Colors */
green-600: #059669 (Success/Low risk)
yellow-600: #D97706 (Warning/Moderate risk)
red-600: #DC2626 (Error/High risk)

/* Neutral Colors */
slate-900: #0F172A (Primary text)
slate-600: #475569 (Secondary text)
slate-200: #E2E8F0 (Borders)
```

## Performance Optimizations

### Code Splitting
- Lazy loading of components
- Dynamic imports for large dependencies
- Route-based code splitting

### Bundle Optimization
- Tree shaking for unused code elimination
- Minification and compression
- Asset optimization

### Runtime Performance
- Memoization of expensive calculations
- Efficient re-rendering patterns
- Optimized event handlers

## Accessibility Features

### WCAG Compliance
- Semantic HTML structure
- ARIA labels and roles
- Keyboard navigation support
- Screen reader compatibility

### Form Accessibility
- Proper label associations
- Error message announcements
- Focus management
- High contrast support

## Browser Compatibility

### Supported Browsers
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Polyfills
- ES6+ features automatically polyfilled by Vite
- CSS Grid and Flexbox support
- Modern JavaScript APIs

## Testing Strategy

### Unit Testing
Recommended testing approach:
```typescript
// Example test structure
describe('mlModel', () => {
  test('should calculate risk score correctly', () => {
    const patientData = { /* test data */ };
    const result = predictCirrhosis(patientData);
    expect(result.riskScore).toBe(expectedScore);
  });
});
```

### Integration Testing
- Component interaction testing
- Form submission workflows
- Navigation state management

### End-to-End Testing
- Complete user workflows
- Cross-browser testing
- Performance testing

## Security Considerations

### Data Privacy
- No data persistence or transmission
- Client-side only processing
- No external API calls for sensitive data

### Input Validation
- Type checking with TypeScript
- Runtime validation for form inputs
- Sanitization of user inputs

### Content Security
- XSS prevention through React's built-in protections
- Safe HTML rendering
- Secure dependency management

## Deployment Architecture

### Build Process
1. TypeScript compilation
2. Asset optimization
3. Bundle generation
4. Static file output

### CDN Strategy
- Static asset delivery
- Global edge caching
- Automatic compression

### Monitoring
- Error tracking integration points
- Performance monitoring hooks
- Analytics event tracking

## Future Enhancements

### Planned Features
- Real-time collaboration
- Advanced data visualization
- Export functionality
- Multi-language support

### Technical Improvements
- Progressive Web App features
- Offline functionality
- Advanced caching strategies
- Micro-frontend architecture

## API Integration Points

### Future Backend Integration
Prepared endpoints for:
- Patient data persistence
- Historical predictions
- User authentication
- Audit logging

### Data Export
- PDF report generation
- CSV data export
- FHIR standard compliance
- HL7 integration support