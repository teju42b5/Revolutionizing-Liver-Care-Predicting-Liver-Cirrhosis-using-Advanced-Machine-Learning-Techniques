import React, { useState } from 'react';
import { User, FlaskConical, Heart, FileText } from 'lucide-react';
import { PatientData } from '../types/medical';

interface PatientFormProps {
  onSubmit: (data: PatientData) => void;
}

export const PatientForm: React.FC<PatientFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<PatientData>({
    age: 45,
    gender: 'male',
    bilirubin: 1.2,
    albumin: 3.5,
    alkalinePhosphatase: 120,
    sgot: 35,
    platelets: 250000,
    prothrombinTime: 12,
    ascites: 'none',
    hepatomegaly: false,
    spiders: false,
    edema: 'none',
    alcoholism: false,
    hepatitisB: false,
    hepatitisC: false,
    fattyLiver: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (field: keyof PatientData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
        <div className="p-8 border-b border-slate-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <User className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Patient Assessment</h2>
              <p className="text-slate-600">Enter patient data for cirrhosis risk prediction</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {/* Demographics */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <User className="h-5 w-5 text-slate-600" />
              <h3 className="text-lg font-semibold text-slate-900">Demographics</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Age (years)
                </label>
                <input
                  type="number"
                  value={formData.age}
                  onChange={(e) => handleChange('age', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  max="120"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Gender
                </label>
                <select
                  value={formData.gender}
                  onChange={(e) => handleChange('gender', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  required
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>
          </div>

          {/* Laboratory Tests */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <FlaskConical className="h-5 w-5 text-slate-600" />
              <h3 className="text-lg font-semibold text-slate-900">Laboratory Results</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Bilirubin (mg/dL)
                  <span className="text-xs text-slate-500 ml-1">Normal: 0.2-1.2</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.bilirubin}
                  onChange={(e) => handleChange('bilirubin', parseFloat(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Albumin (g/dL)
                  <span className="text-xs text-slate-500 ml-1">Normal: 3.5-5.0</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.albumin}
                  onChange={(e) => handleChange('albumin', parseFloat(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Alkaline Phosphatase (U/L)
                  <span className="text-xs text-slate-500 ml-1">Normal: 44-147</span>
                </label>
                <input
                  type="number"
                  value={formData.alkalinePhosphatase}
                  onChange={(e) => handleChange('alkalinePhosphatase', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  SGOT/AST (U/L)
                  <span className="text-xs text-slate-500 ml-1">Normal: 8-40</span>
                </label>
                <input
                  type="number"
                  value={formData.sgot}
                  onChange={(e) => handleChange('sgot', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Platelets (per µL)
                  <span className="text-xs text-slate-500 ml-1">Normal: 150,000-450,000</span>
                </label>
                <input
                  type="number"
                  value={formData.platelets}
                  onChange={(e) => handleChange('platelets', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Prothrombin Time (seconds)
                  <span className="text-xs text-slate-500 ml-1">Normal: 11-13</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.prothrombinTime}
                  onChange={(e) => handleChange('prothrombinTime', parseFloat(e.target.value))}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  min="0"
                  required
                />
              </div>
            </div>
          </div>

          {/* Clinical Parameters */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Heart className="h-5 w-5 text-slate-600" />
              <h3 className="text-lg font-semibold text-slate-900">Clinical Findings</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Ascites
                </label>
                <select
                  value={formData.ascites}
                  onChange={(e) => handleChange('ascites', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  required
                >
                  <option value="none">None</option>
                  <option value="slight">Slight</option>
                  <option value="moderate">Moderate</option>
                  <option value="severe">Severe</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Edema
                </label>
                <select
                  value={formData.edema}
                  onChange={(e) => handleChange('edema', e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  required
                >
                  <option value="none">None</option>
                  <option value="slight">Slight</option>
                  <option value="moderate">Moderate</option>
                  <option value="severe">Severe</option>
                </select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="hepatomegaly"
                  checked={formData.hepatomegaly}
                  onChange={(e) => handleChange('hepatomegaly', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="hepatomegaly" className="ml-2 text-sm font-medium text-slate-700">
                  Hepatomegaly (enlarged liver)
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="spiders"
                  checked={formData.spiders}
                  onChange={(e) => handleChange('spiders', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="spiders" className="ml-2 text-sm font-medium text-slate-700">
                  Spider nevi present
                </label>
              </div>
            </div>
          </div>

          {/* Medical History */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <FileText className="h-5 w-5 text-slate-600" />
              <h3 className="text-lg font-semibold text-slate-900">Medical History</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="alcoholism"
                  checked={formData.alcoholism}
                  onChange={(e) => handleChange('alcoholism', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="alcoholism" className="ml-2 text-sm font-medium text-slate-700">
                  History of alcoholism
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="hepatitisB"
                  checked={formData.hepatitisB}
                  onChange={(e) => handleChange('hepatitisB', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="hepatitisB" className="ml-2 text-sm font-medium text-slate-700">
                  Hepatitis B infection
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="hepatitisC"
                  checked={formData.hepatitisC}
                  onChange={(e) => handleChange('hepatitisC', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="hepatitisC" className="ml-2 text-sm font-medium text-slate-700">
                  Hepatitis C infection
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="fattyLiver"
                  checked={formData.fattyLiver}
                  onChange={(e) => handleChange('fattyLiver', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded"
                />
                <label htmlFor="fattyLiver" className="ml-2 text-sm font-medium text-slate-700">
                  Fatty liver disease
                </label>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end pt-6 border-t border-slate-200">
            <button
              type="submit"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <span>Analyze Patient Data</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};