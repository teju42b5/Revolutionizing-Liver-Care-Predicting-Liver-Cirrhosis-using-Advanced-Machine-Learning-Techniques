import React from 'react';
import { AlertTriangle, CheckCircle, XCircle, TrendingUp, Brain, FileText, Download } from 'lucide-react';
import { PredictionResult, PatientData } from '../types/medical';

interface PredictionResultsProps {
  result: PredictionResult;
  patientData: PatientData;
  onNewPrediction: () => void;
}

export const PredictionResults: React.FC<PredictionResultsProps> = ({ 
  result, 
  patientData, 
  onNewPrediction 
}) => {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-700 bg-green-50 border-green-200';
      case 'moderate': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      case 'high': return 'text-orange-700 bg-orange-50 border-orange-200';
      case 'very-high': return 'text-red-700 bg-red-50 border-red-200';
      default: return 'text-gray-700 bg-gray-50 border-gray-200';
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'low': return CheckCircle;
      case 'moderate': return AlertTriangle;
      case 'high': return AlertTriangle;
      case 'very-high': return XCircle;
      default: return AlertTriangle;
    }
  };

  const getFactorColor = (impact: string) => {
    switch (impact) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const RiskIcon = getRiskIcon(result.riskLevel);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Brain className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Cirrhosis Risk Assessment</h2>
              <p className="text-slate-600">AI-powered prediction results</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <button className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 transition-colors flex items-center space-x-2">
              <Download className="h-4 w-4" />
              <span>Export Report</span>
            </button>
            <button
              onClick={onNewPrediction}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              New Assessment
            </button>
          </div>
        </div>

        {/* Main Risk Score */}
        <div className={`rounded-xl p-6 border-2 ${getRiskColor(result.riskLevel)}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <RiskIcon className="h-8 w-8" />
              <div>
                <h3 className="text-2xl font-bold capitalize">{result.riskLevel.replace('-', ' ')} Risk</h3>
                <p className="text-sm opacity-80">Cirrhosis Development Risk</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{result.riskScore}%</div>
              <div className="text-sm opacity-80">Risk Score</div>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Confidence Level</span>
              <span>{result.confidence}%</span>
            </div>
            <div className="w-full bg-white bg-opacity-30 rounded-full h-2">
              <div 
                className="bg-current h-2 rounded-full transition-all duration-1000" 
                style={{ width: `${result.confidence}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Factors */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            Key Risk Factors
          </h3>
          <div className="space-y-3">
            {result.riskFactors.map((factor, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-slate-900">{factor.factor}</h4>
                  <p className="text-sm text-slate-600">{factor.value}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getFactorColor(factor.impact)}`}>
                  {factor.impact} impact
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Stage & Recommendations */}
        <div className="space-y-6">
          {/* Disease Stage */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Disease Stage</h3>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">Stage {result.stage}</div>
              <div className="text-sm text-slate-600">
                {result.stage === 1 && "Mild fibrosis"}
                {result.stage === 2 && "Moderate fibrosis"}
                {result.stage === 3 && "Severe fibrosis"}
                {result.stage === 4 && "Cirrhosis"}
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between mb-1">
                <span className="text-xs text-slate-500">Stage 1</span>
                <span className="text-xs text-slate-500">Stage 4</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-green-500 to-red-500 h-2 rounded-full"
                  style={{ width: `${(result.stage / 4) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Recommendations
            </h3>
            <ul className="space-y-2">
              {result.recommendations.map((rec, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-slate-700">{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Patient Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Patient Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="text-sm text-slate-600">Age / Gender</div>
            <div className="font-semibold text-slate-900">{patientData.age} years / {patientData.gender}</div>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="text-sm text-slate-600">Bilirubin</div>
            <div className="font-semibold text-slate-900">{patientData.bilirubin} mg/dL</div>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="text-sm text-slate-600">Albumin</div>
            <div className="font-semibold text-slate-900">{patientData.albumin} g/dL</div>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <div className="text-sm text-slate-600">Platelets</div>
            <div className="font-semibold text-slate-900">{patientData.platelets.toLocaleString()}/µL</div>
          </div>
        </div>
      </div>
    </div>
  );
};