import React from 'react';
import { TrendingUp, Users, Activity, AlertTriangle, Plus, Brain } from 'lucide-react';

interface DashboardProps {
  onNewPrediction: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNewPrediction }) => {
  const stats = [
    {
      label: 'Total Predictions',
      value: '2,847',
      change: '+12%',
      changeType: 'positive' as const,
      icon: Activity,
    },
    {
      label: 'High-Risk Cases',
      value: '342',
      change: '+8%',
      changeType: 'neutral' as const,
      icon: AlertTriangle,
    },
    {
      label: 'Model Accuracy',
      value: '94.2%',
      change: '+2.1%',
      changeType: 'positive' as const,
      icon: Brain,
    },
    {
      label: 'Patients Monitored',
      value: '1,523',
      change: '+15%',
      changeType: 'positive' as const,
      icon: Users,
    },
  ];

  const recentPredictions = [
    { id: 1, patient: 'Patient #A1234', risk: 'High', score: 82, date: '2025-01-10' },
    { id: 2, patient: 'Patient #B5678', risk: 'Low', score: 23, date: '2025-01-10' },
    { id: 3, patient: 'Patient #C9012', risk: 'Moderate', score: 54, date: '2025-01-09' },
    { id: 4, patient: 'Patient #D3456', risk: 'High', score: 78, date: '2025-01-09' },
    { id: 5, patient: 'Patient #E7890', risk: 'Low', score: 31, date: '2025-01-08' },
  ];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low': return 'text-green-700 bg-green-100';
      case 'Moderate': return 'text-yellow-700 bg-yellow-100';
      case 'High': return 'text-red-700 bg-red-100';
      default: return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Welcome to LiverCare AI</h2>
            <p className="text-blue-100 text-lg max-w-2xl">
              Revolutionizing liver care through advanced machine learning. Predict cirrhosis risk 
              with 94.2% accuracy using our state-of-the-art AI model trained on thousands of clinical cases.
            </p>
          </div>
          <button
            onClick={onNewPrediction}
            className="bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span>New Prediction</span>
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-lg">
                <stat.icon className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center mt-4">
              <TrendingUp className={`h-4 w-4 mr-1 ${
                stat.changeType === 'positive' ? 'text-green-500' : 'text-gray-500'
              }`} />
              <span className={`text-sm font-medium ${
                stat.changeType === 'positive' ? 'text-green-600' : 'text-gray-600'
              }`}>
                {stat.change} from last month
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Predictions */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200">
        <div className="p-6 border-b border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900">Recent Predictions</h3>
          <p className="text-sm text-slate-600 mt-1">Latest cirrhosis risk assessments</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Patient ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Risk Level
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Risk Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Date
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {recentPredictions.map((prediction) => (
                <tr key={prediction.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                    {prediction.patient}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRiskColor(prediction.risk)}`}>
                      {prediction.risk}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                    {prediction.score}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                    {prediction.date}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Model Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Model Performance</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Accuracy</span>
                <span className="font-medium">94.2%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '94.2%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Sensitivity</span>
                <span className="font-medium">91.8%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: '91.8%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Specificity</span>
                <span className="font-medium">96.3%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                <div className="bg-teal-600 h-2 rounded-full" style={{ width: '96.3%' }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Risk Distribution</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Low Risk</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-slate-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
                <span className="text-sm font-medium">60%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">Moderate Risk</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-slate-200 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '25%' }}></div>
                </div>
                <span className="text-sm font-medium">25%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600">High Risk</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-slate-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                </div>
                <span className="text-sm font-medium">15%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};