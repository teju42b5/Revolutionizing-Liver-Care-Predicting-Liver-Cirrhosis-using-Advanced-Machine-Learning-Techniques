export interface PatientData {
  // Demographics
  age: number;
  gender: 'male' | 'female';
  
  // Laboratory Tests
  bilirubin: number; // mg/dL
  albumin: number; // g/dL
  alkalinePhosphatase: number; // U/L
  sgot: number; // U/L (AST)
  platelets: number; // per µL
  prothrombinTime: number; // seconds
  
  // Clinical Parameters
  ascites: 'none' | 'slight' | 'moderate' | 'severe';
  hepatomegaly: boolean;
  spiders: boolean; // Spider nevi
  edema: 'none' | 'slight' | 'moderate' | 'severe';
  
  // Medical History
  alcoholism: boolean;
  hepatitisB: boolean;
  hepatitisC: boolean;
  fattyLiver: boolean;
}

export interface PredictionResult {
  riskScore: number; // 0-100
  riskLevel: 'low' | 'moderate' | 'high' | 'very-high';
  confidence: number; // 0-100
  stage: 1 | 2 | 3 | 4;
  recommendations: string[];
  riskFactors: {
    factor: string;
    impact: 'low' | 'moderate' | 'high';
    value: string;
  }[];
}

export interface LabValue {
  name: string;
  value: number;
  unit: string;
  normalRange: string;
  status: 'normal' | 'borderline' | 'abnormal';
}