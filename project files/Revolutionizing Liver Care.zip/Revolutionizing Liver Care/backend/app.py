
from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load model and scaler
model = joblib.load('liver_model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    df = pd.DataFrame([data])
    df_scaled = scaler.transform(df)
    prediction = model.predict(df_scaled)[0]
    probability = model.predict_proba(df_scaled)[0][1]
    return jsonify({
        'prediction': 'Liver Disease' if prediction == 1 else 'No Liver Disease',
        'confidence': round(probability, 2)
    })

if __name__ == '__main__':
    app.run(debug=True)
