# Deployment Guide

## Netlify Deployment (Recommended)

### Automatic Deployment
The easiest way to deploy this application is using Netlify's automatic deployment:

1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Connect your repository to Netlify
3. Set build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Deploy automatically on every push

### Manual Deployment
1. Build the project:
```bash
npm run build
```

2. Upload the `dist` folder to Netlify

### Environment Variables
No environment variables are required for basic functionality.

## Other Deployment Options

### Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow the prompts

### GitHub Pages
1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json scripts:
```json
"homepage": "https://yourusername.github.io/liver-cirrhosis-predictor",
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```
3. Run: `npm run deploy`

### Docker Deployment
1. Create Dockerfile:
```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

2. Build and run:
```bash
docker build -t liver-cirrhosis-predictor .
docker run -p 80:80 liver-cirrhosis-predictor
```

## Build Optimization

### Production Build
```bash
npm run build
```

### Build Analysis
To analyze bundle size:
```bash
npm install --save-dev vite-bundle-analyzer
```

Add to vite.config.ts:
```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { analyzer } from 'vite-bundle-analyzer'

export default defineConfig({
  plugins: [react(), analyzer()],
  // ... other config
})
```

## Performance Optimization

### Code Splitting
The application uses React.lazy() for code splitting:
```typescript
const Dashboard = React.lazy(() => import('./components/Dashboard'))
```

### Asset Optimization
- Images are optimized and served from CDN
- CSS is minified and purged
- JavaScript is minified and tree-shaken

### Caching Strategy
- Static assets have long cache headers
- HTML has short cache headers for updates
- Service worker for offline functionality (optional)

## Monitoring and Analytics

### Error Tracking
Consider integrating:
- Sentry for error tracking
- LogRocket for session replay
- Google Analytics for usage analytics

### Performance Monitoring
- Lighthouse CI for performance audits
- Web Vitals monitoring
- Real User Monitoring (RUM)

## Security Considerations

### Content Security Policy
Add CSP headers:
```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';
```

### HTTPS
Always deploy with HTTPS enabled (automatic with Netlify/Vercel).

### Data Privacy
- No patient data is stored or transmitted
- All processing happens client-side
- Consider HIPAA compliance for production use

## Troubleshooting

### Build Issues
- Clear node_modules and reinstall: `rm -rf node_modules package-lock.json && npm install`
- Check Node.js version compatibility (requires Node 16+)

### Runtime Issues
- Check browser console for errors
- Verify all dependencies are installed
- Ensure build artifacts are properly generated

### Performance Issues
- Enable production build optimizations
- Check network tab for large assets
- Implement lazy loading for components